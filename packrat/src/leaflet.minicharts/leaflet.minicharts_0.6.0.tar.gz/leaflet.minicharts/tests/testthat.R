library(testthat)
library(leaflet.minicharts)

test_check("leaflet.minicharts")
